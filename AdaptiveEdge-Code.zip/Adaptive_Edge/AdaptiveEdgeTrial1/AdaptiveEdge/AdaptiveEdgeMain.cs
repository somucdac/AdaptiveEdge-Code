﻿///This is a program for edge detection using adaptive DOG.
///This part of the program includes library files

using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using EdgeCustom;
using System.Windows.Forms;
using AdaptiveEdgeTrial1;





namespace AdaptiveEdgeTrial1.AdaptiveEdge
{
    public class AdaptiveEdgeMain : MainWindow
    {
        //This part of the program declares variables

        Double[,]        testValues;
        Boolean[,]       EdgeMapboolHorizontal;
        Boolean[,]       EdgeMapboolVertical;
        Boolean[,]       EdgeMapbool;
        Double sigma     = 0.0;
        
        [DllImport("FC_Final_V3.0_x64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern Double FC_Final_V3([MarshalAs(UnmanagedType.LPArray)]Double[] testStrip);
        //AdaptiveEdgeTrial1.MainWindow mw = new MainWindow();


        //Constructor of the class AdaptiveEdgeMain 

        public Boolean[,] AdaptiveEdgeMainCalculator(Double[,] intensityValues, Int32 startX, Int32 startY, Int32 endX, Int32 endY,Double sig1,Double sig2,Double sig3,Double sig4,Double sig5)
        {

            //This part of the program initializes different variables.
            //In this part of the program image pixel values along with zero padding is stored in the array testValues.







            Int32 height = intensityValues.GetLength(0);
            Int32 width = intensityValues.GetLength(1);

            testValues = new Double[(height + 9), (width + 9)];
            

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    testValues[i, j] = intensityValues[i, j];
                }
            }

            
            // Split the test values into four seperate compartments

            



            EdgeMapboolHorizontal   = new Boolean[(endY -startY) + 9, (endX - startX) + 9];
            EdgeMapboolVertical = new Boolean[(endY - startY) + 9, (endX - startX) + 9];
            EdgeMapbool = new Boolean[(endY - startY), (endX - startX)];
            //variable declaration

            Double[,]        smallWindow;
            Double[]        testStripH;
            Double[]        testStripV;
            Double[,]        dog;
            Double[,]        bigWindow;
            
            Int32[]         serialArrayX;
            Int32[]         serialArrayY;
            
            Int32           index                   = 0;
            Double           error                  = 0.0;
            Int32           windowSize              = 0;
            Double          maxH                    = 0.0;
            Double          minH                    = 99999.99;
            Double          maxV                    = 0.0;
            Double          minV                    = 99999.99;
            Int32           padNX                   = 0;
            Int32           padNY                   = 0;
            Int32           padPX                   = 0;
            Int32           padPY                   = 0;
            Object          lockObject              =   new Object();
            

            //This part of the program computes the edge map using adaptive DOG.
            //MessageBox.Show("Entry");
            for(int i = startY;i < endY; i++)
            //for (int i = startY; i < 6; i++)
            {
                for(int j = startX;j < endX; j++)
                {

                        index = 0;
                        smallWindow = new Double[9, 9];
                        maxH = 0.0;
                        minH = 99999.0;
                        maxV = 0.0;
                        minV = 99999.0;
                        
                        padNX = 0;
                        padNY = 0;
                        padPX = 0;
                        padPY = 0;

                        
                        testStripH = new Double[9];
                        testStripV = new Double[9];
                    

                        // This part of the program creatres the 9x9 window around th3e target pixel. Extracts the 5 th row(For Horizontal Scanning) , or the 5th Column(For Vertical Scanning)
                        // Finds the difference between maximum and minimum values of the pixels.
                        if (i - 4 >= 0 && j - 4 >= 0)
                        {
                            for (int k = i - 4; k <= i + 4; k++)
                            {
                                for (int l = j - 4; l <= j + 4; l++)
                                {
                                    smallWindow[(k - (i - 4)), (l - (j - 4))] = testValues[k, l];
                                    if (k - (i - 4) == 4)
                                    {
                                        testStripH[l - (j - 4)] = smallWindow[(k - (i - 4)), (l - (j - 4))];
                                        if (testStripH[l - (j - 4)] > maxH)
                                        {
                                            maxH = testStripH[l - (j - 4)];
                                        }
                                        else if (testStripH[l - (j - 4)] < minH)
                                            minH = testStripH[l - (j - 4)];
                                    }
                                    if (l - (j - 4) == 4)
                                    {
                                        testStripV[k - (i - 4)] = smallWindow[(k - (i - 4)), (l - (j - 4))];
                                        if (testStripV[k - (i - 4)] > maxV)
                                        {
                                            maxV = testStripV[k - (i - 4)];
                                        }
                                        else if (testStripV[k - (i - 4)] < minV)
                                            minV = testStripV[k - (i - 4)];
                                    }

                                }
                            }
                        }
                        else
                            continue;

                        //MessageBox.Show("Step1");
                        // In this part of the program the difference between the max and min values of the pixel is compared with 5. If less than 5 
                        // the region is homogeneous and the window shifts to the next part.
                    //This part of the program calculates the max and min values of the pixels in a strip if the difference is less than 5 then it is considered as a non edge homogenious region
                        if (maxH - minH > 21)
                        {
                            error = ErrorCalculator(testStripH); // This function calulates the error.
                            //text
                            windowSize = WindowSizeCalculator(error,sig1,sig2,sig3,sig4,sig5); // This function takes the erroir value consults the lookup table and decides the suppression region variance.
                            dog = CalculateDOG(windowSize); // This function computes the dog with new variance.

                            // Four variables are defined to decide the size of the padding.
                            padNX = 0;
                            padNY = 0;
                            padPX = 0;
                            padPY = 0;
                            
                            // This part of the [program initialises the new window.
                            bigWindow = new Double[windowSize, windowSize];


                            serialArrayX = new Int32[windowSize];
                            serialArrayY = new Int32[windowSize];

                            


                            // This part computes the amounts of padding and creates window with new size.
                            
                            if (i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) < 0)
                            {
                                padNY = Math.Abs(i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0));
                            }
                            if (j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) < 0)
                            {
                                padNX = Math.Abs(j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0));
                            }
                            if (i + (int)Math.Floor((double)(windowSize - 1) / 2.0) - height > 0)
                            {
                                padPY = Math.Abs(i + ((int)Math.Floor((double)(windowSize - 1) / 2.0) - height));
                            }
                            if (j + (int)Math.Floor((double)(windowSize - 1) / 2.0) - width > 0)
                            {
                                padPX = Math.Abs((j + (int)Math.Floor((double)(windowSize - 1) / 2.0) - width));
                            }

                            for (int si = 0; si < windowSize; si++)
                            {

                                if (si < padNX)
                                    serialArrayX[si] = j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + padNX;
                                else if (si >= padNX && si <= windowSize - padPX - 1)
                                    serialArrayX[si] = j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + si;
                                else
                                {
                                    if (si > windowSize - padPX - 1)
                                    {
                                        serialArrayX[si] = j + (int)Math.Ceiling((double)(windowSize - 1) / 2.0) - padPX - 1;
                                    }
                                }

                                if (si < padNY)
                                    serialArrayY[si] = i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + padNY;
                                else if (si >= padNY && si <= windowSize - padPY - 1)
                                    serialArrayY[si] = i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + si;
                                else
                                {
                                    if (si > windowSize - padPY - 1)
                                    {
                                        serialArrayY[si] = i + (int)Math.Ceiling((double)(windowSize - 1) / 2.0) - padPY - 1;
                                    }
                                }

                            }
                            for (int bi = 0; bi < windowSize; bi++)
                            {
                                for (int bj = 0; bj < windowSize; bj++)
                                {
                                    bigWindow[bi, bj] = testValues[serialArrayY[bi], serialArrayX[bj]];
                                }
                            }


                            // ----------------------------------------------------------------------------------------------------------------------------------------



                            //  Calculation of the Edge Map
                            // ----------------------------------------------------------------------------------------------------------------------------------------

                            EdgeMapboolHorizontal[i - startY, j - startX] = GetEdgeValue(bigWindow, dog, "ZeroCross", 0.0092, windowSize); // This function calulates the EdgeMap.
                            
                        }
                        //MessageBox.Show("Step2");
                        // This part repeats the same operation for the vertical edge.
                        if (maxV - minV >21)
                        {
                            error = ErrorCalculator(testStripV);
                            windowSize = WindowSizeCalculator((Int32)error, sig1, sig2, sig3, sig4, sig5);
                            dog = CalculateDOG(windowSize);
                            padNX = 0;
                            padNY = 0;
                            padPX = 0;
                            padPY = 0;
                            bigWindow = new Double[windowSize, windowSize];

                            serialArrayX = new Int32[windowSize];
                            serialArrayY = new Int32[windowSize];

                            // ----------------------------------------------------------------------------------------------------------------------------------------


                            // Write the code for implementing padding here
                            // ----------------------------------------------------------------------------------------------------------------------------------------

                            if (i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) < 0)
                            {
                                padNY = Math.Abs(i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0));
                            }
                            if (j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) < 0)
                            {
                                padNX = Math.Abs(j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0));
                            }
                            if (i + (int)Math.Floor((double)(windowSize - 1) / 2.0) - width > 0)
                            {
                                padPY = Math.Abs(i + ((int)Math.Floor((double)(windowSize - 1) / 2.0) - height));
                            }
                            if (j + (int)Math.Floor((double)(windowSize - 1) / 2.0) - width > 0)
                            {
                                padPX = Math.Abs((j + (int)Math.Floor((double)(windowSize - 1) / 2.0) - width));
                            }

                            for (int si = 0; si < windowSize; si++)
                            {

                                if (si < padNX)
                                    serialArrayX[si] = j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + padNX;
                                else if (si >= padNX && si <= windowSize - padPX - 1)
                                    serialArrayX[si] = j - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + si;
                                else
                                {
                                    if (si > windowSize - padPX - 1)
                                    {
                                        serialArrayX[si] = j + (int)Math.Ceiling((double)(windowSize - 1) / 2.0) - padPX - 1;
                                    }
                                }

                                if (si < padNY)
                                    serialArrayY[si] = i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + padNY;
                                else if (si >= padNY && si <= windowSize - padPY - 1)
                                    serialArrayY[si] = i - (int)Math.Ceiling((double)(windowSize - 1) / 2.0) + si;
                                else
                                {
                                    if (si > windowSize - padPY - 1)
                                    {
                                        serialArrayY[si] = i + (int)Math.Ceiling((double)(windowSize - 1) / 2.0) - padPY - 1;
                                    }
                                }

                            }
                            for (int bi = 0; bi < windowSize; bi++)
                            {
                                for (int bj = 0; bj < windowSize; bj++)
                                {
                                    bigWindow[bi, bj] = testValues[serialArrayY[bi], serialArrayX[bj]];
                                }
                            }


                            // ----------------------------------------------------------------------------------------------------------------------------------------



                            //  Calculate the Edge Map
                            // ----------------------------------------------------------------------------------------------------------------------------------------

                            EdgeMapboolVertical[i - startY, j - startX] = GetEdgeValue(bigWindow, dog, "ZeroCross", 0.0092, windowSize);
                        }

                        //MessageBox.Show("Step3");

                }
                
                
            }
            //MessageBox.Show("Exit");
            // This part of the program fuses Horizontal edgepoints and Vertical Edgepoints to create a new File : EdgeMap.txt to store the complete edge pixel set
            for (int i = 0; i < endY - startY; i++)
                for (int j = 0; j < endX - startX; j++)
                    EdgeMapbool[i, j] = EdgeMapboolHorizontal[i,j] || EdgeMapboolVertical[i,j];
            

            
            return EdgeMapbool;
        }

        // Definitions of different functions.

        public Double ErrorCalculator(Double[] testStrip)
        {
            Double error = 0;
            error  = FC_Final_V3(testStrip);
            return error;
        }

        public Double[,] CalculateDOG(Int32 windowSize)
        {
            Double[,] g1     =   GaussianMatlab(windowSize,1.0);
            Double[,] g2     =   GaussianMatlab(windowSize, sigma);

            Double[,] dog = new Double[windowSize , windowSize];

            for (int i = 0; i < windowSize; i++)
            {
                for (int j = 0; j < windowSize; j++)
                {
                    dog[i,j] = g1[i,j] - (g2[i,j]);
                }
            }
            return dog;

        }


        private Double[,] GaussianMatlab(Int32 windowSize, Double sigma)
        {
            
            Double size = (windowSize - 1) / 2.0;
            Double[,] x     =   new Double[windowSize,windowSize];
            Double[,] y     =   new Double[windowSize,windowSize];
            Double[,] arg   =   new Double[windowSize, windowSize];
            Double[,] h     =   new Double[windowSize, windowSize];
            Double[,] result = new Double[windowSize , windowSize];
            Double epsilon = 2.2204e-016;

            

            for (int i = 0; i < windowSize; i++)
            {
                for (int j = 0; j < windowSize; j++)
                {
                    x[i, j] = (-1 * size) + j;
                    y[j, i] = (-1 * size) + j;
                }
            }

            Double max =0.0;
            Double sum = 0.0;

            for (int i = 0; i < windowSize; i++)
            {
                for (int j = 0; j < windowSize; j++)
                {
                    arg[i, j] = -1 * (Math.Pow(x[i,j],2) + Math.Pow(y[i,j],2)) / (2 * (Math.Pow(sigma, 2)));
                    h[i, j] = Math.Exp(arg[i, j]);
                    if(h[i,j] > max)
                        max = h[i,j];
                    sum = sum + h[i, j];
                }
            }
           
            for (int i = 0; i < windowSize; i++)
            {
                for (int j = 0; j < windowSize; j++)
                {
                    if (h[i, j] < epsilon * max)
                        h[i, j] = 0.0;
                    if (sum != 0)
                        h[i, j] = h[i, j] / sum;
                    result[i,j] = h[i,j];

                }
                
            }
            
            return result;
        }
        //This part contains lookup table values. 
        public Int32 WindowSizeCalculator(Double errorD, Double sig1, Double sig2, Double sig3, Double sig4, Double sig5)
        {
            Int32 windowSize = 0;
            // Write the code for calculation of WindowSize here after going through the lookup table
            
            Int32 error = (Int32)Math.Ceiling(errorD);

            //if (error >= 0 && error < 251)
            //{
            //    windowSize = 13;
            //    sigma = 2.6;
            //}
            //else if (error >= 251 && error < 281)
            //{
            //    windowSize = 15;
            //    sigma = 3.1;
            //}
            //else if (error >= 281 && error < 294)
            //{
            //    windowSize = 19;
            //    sigma = 3.6;
            //}
            //else if (error >= 294 && error < 321)
            //{
            //    windowSize = 129;
            //    sigma = 25.6;
            //}
            //else
            //{
            //    windowSize = 13;
            //    sigma = 2.6;

            //}

            //Lookup table for eggonpot
            if (error >= 0 && error < 213)
            {
                //windowSize = 7;
                windowSize = (Int32)Math.Floor(sig1*2);
                sigma = sig1;
                //sigma = 
                //sigma = Convert.ToDouble(textBox1.Text);
                
                
                
                
           }
            else if (error >= 214 && error < 236)
            {
                //windowSize = 9;
                windowSize = (Int32)Math.Floor(sig2 * 2);
                sigma = sig2;
                //sigma = Convert.ToDouble(textBox2.Text);
                
            }
            else if (error >= 237 && error < 286)
            {
                //windowSize = 11;
                windowSize = (Int32)Math.Floor(sig3 * 2);
                sigma = sig3;
                //sigma = Convert.ToDouble(textBox3.Text);
                
            }
            else if (error >= 287 && error < 310)
            {
                //windowSize = 69;
                //windowSize = 64;
                windowSize = (Int32)Math.Floor(sig4 * 2);
                sigma = sig4;
                //sigma = 32.0;
                
                
            }
            else
            {
                //windowSize = 7;
                windowSize = (Int32)Math.Floor(sig5 * 2);
                sigma = sig5;
                //sigma = Convert.ToDouble(textBox5.Text);
               
                

            }


            //if (error >= 0 && error < 251)
            //{
            //    windowSize = 13;
            //    sigma = 2.6;
            //}
            //else if (error >= 251 && error < 281)
            //{
            //    windowSize = 23;
            //    sigma = 4.6;
            //}
            //else if (error >= 281 && error < 294)
            //{
            //    windowSize = 43;
            //    sigma = 8.6;
            //}
            //else if (error >= 294 && error < 321)
            //{
            //    windowSize = 153;
            //    sigma = 30.6;
            //}
            //else
            //{
            //    windowSize = 13;
            //    sigma = 2.6;

            //}
            return windowSize;
        }

        public Boolean GetEdgeValue(Double[,] intensityValues, Double[,] dog, String method, Double zeroCrossThreshold, Int32 windowSize)
        {
            Boolean edgeValue = false;
            

            // Write the code for calling the edge function inside this function....
            MathWorks.MATLAB.NET.Arrays.MWNumericArray na = new MathWorks.MATLAB.NET.Arrays.MWNumericArray(intensityValues);
            MathWorks.MATLAB.NET.Arrays.MWNumericArray mwDog = new MathWorks.MATLAB.NET.Arrays.MWNumericArray(dog);
            MathWorks.MATLAB.NET.Arrays.MWCharArray arr = "zerocross";

            //Edge e = null;
            Edge e = new Edge();

            MathWorks.MATLAB.NET.Arrays.MWArray varargout = e.ComputeEdgeMap(na, new MathWorks.MATLAB.NET.Arrays.MWNumericArray(zeroCrossThreshold), mwDog);
            
            Array ar = varargout.ToArray();
            return (Boolean)ar.GetValue(0,0);
        }
    }
}
