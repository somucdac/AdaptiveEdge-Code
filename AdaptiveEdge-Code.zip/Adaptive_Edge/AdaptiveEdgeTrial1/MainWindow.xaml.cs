﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Net.Cache;

namespace AdaptiveEdgeTrial1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        String fileName;
        public Double[,] intensityValues ;
        public System.Drawing.Bitmap bmp ;
        Int32 dimension = 0;
        Bitmap Image ;
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.ShowDialog();

            fd.Multiselect = false;
            fileName = fd.FileName;
            bmp = new System.Drawing.Bitmap(fileName);
            //Int32 dimension = 0;
            
            intensityValues = new Double[bmp.Height, bmp.Width];
            
            for (int i = 0; i < bmp.Height; i++)
            {
                for (int j = 0; j < bmp.Width; j++)
                {
                    intensityValues[i,j] = ((System.Drawing.Color)(bmp.GetPixel(j,i))).R;
                    
                }
            }

            BitmapImage img = new BitmapImage(new Uri(fileName));
            image1.Source = img;

        }

        private void ToBitmap(double[,] rawImage)
        {
            int width = rawImage.GetLength(1);
            int height = rawImage.GetLength(0);

            Image = new Bitmap(height, width);

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    double color = rawImage[i, j];
                    byte rgb = (byte)(color * 255);
                    Int32 rgb1 = (Int32)rgb;
                    Image.SetPixel(i, j, System.Drawing.Color.FromArgb(rgb, rgb, rgb));
                }
            }

            string outputFileName = "result.bmp";
            using (MemoryStream memory = new MemoryStream())
            {
                using (var fs = new FileStream(outputFileName, FileMode.Create, FileAccess.ReadWrite))
                {
                    //Image.
                    Image.Save(memory, System.Drawing.Imaging.ImageFormat.Bmp);
                    byte[] bytes = memory.ToArray();
                    fs.Write(bytes, 0, bytes.Length);
                    //fs.Dispose();
                    //fs.Close();
                }
                
            }
            //Image.Dispose();
            
            //Image.Save("result.bmp", System.Drawing.Imaging.ImageFormat.Bmp);
            //return Image;
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Boolean[,] finalEdgeMap = new Boolean[bmp.Height, bmp.Width];

            if (bmp.Width > bmp.Height)
                dimension = bmp.Width;
            else if (bmp.Width < bmp.Height)
                dimension = bmp.Height;
            else
                dimension = bmp.Width;

            Int32 totalDimension = 0;
            if ((dimension) % 2 != 0)
                totalDimension = dimension + 2 - (dimension) % 2;
            else
                totalDimension = dimension;


            Boolean[,] compartment1B = new Boolean[totalDimension / 2, totalDimension / 2];
            Boolean[,] compartment2B = new Boolean[totalDimension / 2, totalDimension / 2];
            Boolean[,] compartment3B = new Boolean[totalDimension / 2, totalDimension / 2];
            Boolean[,] compartment4B = new Boolean[totalDimension / 2, totalDimension / 2];
            AdaptiveEdge.AdaptiveEdgeMain compartment1Main = new AdaptiveEdge.AdaptiveEdgeMain();
            AdaptiveEdge.AdaptiveEdgeMain compartment2Main = new AdaptiveEdge.AdaptiveEdgeMain();
            AdaptiveEdge.AdaptiveEdgeMain compartment3Main = new AdaptiveEdge.AdaptiveEdgeMain();
            AdaptiveEdge.AdaptiveEdgeMain compartment4Main = new AdaptiveEdge.AdaptiveEdgeMain();

            Double sig1 = Convert.ToDouble(textBox1.Text);
            Double sig2 = Convert.ToDouble(textBox2.Text);
            Double sig3 = Convert.ToDouble(textBox3.Text);
            Double sig4 = Convert.ToDouble(textBox4.Text);
            Double sig5 = Convert.ToDouble(textBox5.Text);

            System.Windows.MessageBox.Show("Started At:" + System.DateTime.Now);
            
            System.Threading.Tasks.Parallel.Invoke(
                                                    () =>
                                                        compartment1B = compartment1Main.AdaptiveEdgeMainCalculator(intensityValues, 0, 0, totalDimension / 2, totalDimension / 2, sig1, sig2, sig3, sig4, sig5),
                                                    () =>
                                                        compartment2B = compartment2Main.AdaptiveEdgeMainCalculator(intensityValues, 0, totalDimension / 2, totalDimension / 2, totalDimension, sig1, sig2, sig3, sig4, sig5),
                                                    () =>
                                                       compartment3B = compartment3Main.AdaptiveEdgeMainCalculator(intensityValues, totalDimension / 2, 0, totalDimension, totalDimension / 2, sig1, sig2, sig3, sig4, sig5),

                                                    () =>
                                                       compartment4B = compartment4Main.AdaptiveEdgeMainCalculator(intensityValues, totalDimension / 2, totalDimension / 2, totalDimension, totalDimension, sig1, sig2, sig3, sig4, sig5)

                                                   );

            for (int i = 0; i < bmp.Height; i++)
            {
                for (int j = 0; j < bmp.Width; j++)
                {
                    if (i < totalDimension / 2 && j < totalDimension / 2)
                    {
                        finalEdgeMap[i, j] = compartment1B[i, j];
                        //compartment1Btxt.Write(Convert.ToInt32(compartment1B[i, j]) + ";");
                    }
                    else if (i >= totalDimension / 2 && i < totalDimension && j < totalDimension / 2)
                    {
                        finalEdgeMap[i, j] = compartment2B[i - totalDimension / 2, j];
                        //compartment2Btxt.Write(Convert.ToInt32(compartment2B[i - totalDimension / 2, j]) + ";");
                    }
                    else if (i < totalDimension / 2 && j >= totalDimension / 2 && j < totalDimension)
                    {
                        finalEdgeMap[i, j] = compartment3B[i, j - totalDimension / 2];
                        //compartment3Btxt.Write(Convert.ToInt32(compartment3B[i, j - totalDimension / 2]) + ";");
                    }
                    else if (i >= totalDimension / 2 && i < totalDimension && j >= totalDimension / 2 && j < totalDimension)
                    {
                        finalEdgeMap[i, j] = compartment4B[i - totalDimension / 2, j - totalDimension / 2];
                        //compartment4Btxt.Write(Convert.ToInt32(compartment4B[i - totalDimension / 2, j - totalDimension / 2]) + ";");
                    }

                    //edgeOutput.Write(Convert.ToInt32(finalEdgeMap[i,j]) + ";");

                }
                
            }
            
            Double[,] doubleImage = new Double[finalEdgeMap.GetLength(0), finalEdgeMap.GetLength(1)];
            for (int s = 0; s < finalEdgeMap.GetLength(0); s++)
            {
                for (int n = 0; n < finalEdgeMap.GetLength(1); n++)
                {
                    if (finalEdgeMap[s, n] == false)
                        doubleImage[n, s] = 0.00;
                    else if (finalEdgeMap[s, n] == true)
                        doubleImage[n, s] = 1.00;
                }
            }
            ToBitmap(doubleImage);
            String path = System.Environment.CurrentDirectory;
            //BitmapImage resImage = new BitmapImage(new Uri(path + "\\result.bmp"));
            BitmapImage resImage = new BitmapImage();
            /*resImage.BeginInit();
            resImage.CacheOption = BitmapCacheOption.OnLoad;
            resImage.UriSource = new Uri(path+"\\result.bmp");
            resImage.EndInit();
            String path1 = path+"\\result.bmp";
            image2.Source = resImage;
            System.Windows.MessageBox.Show("Finished At:" + System.DateTime.Now);
            Image.Dispose();*/


            resImage.BeginInit();
            resImage.CacheOption = BitmapCacheOption.None;
            resImage.UriCachePolicy = new RequestCachePolicy(RequestCacheLevel.BypassCache);
            resImage.CacheOption = BitmapCacheOption.OnLoad;
            resImage.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            resImage.UriSource = new Uri(path + "\\result.bmp", UriKind.RelativeOrAbsolute);
            resImage.EndInit();
            image2.Source = resImage;
            System.Windows.MessageBox.Show("Finished At:" + System.DateTime.Now);
            Image.Dispose();


            //resImage.Dispatcher.DisableProcessing();
            //File.Delete(path1);
            
            //if(File.Exists(Uri(path+"\\result.bmp"));




        }


        //public int dimension { get; set; }

        //public Bitmap bmp { get; set; }
    }
}
